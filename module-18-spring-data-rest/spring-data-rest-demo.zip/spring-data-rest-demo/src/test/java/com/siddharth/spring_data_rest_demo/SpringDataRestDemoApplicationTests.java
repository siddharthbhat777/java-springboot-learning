package com.siddharth.spring_data_rest_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataRestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
